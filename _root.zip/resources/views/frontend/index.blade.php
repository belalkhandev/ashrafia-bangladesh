@extends('frontend.layouts.master')

@section('content')
    {{-- home page --}}
@endsection
