<!-- footer area -->
<footer class="footer-area">
    <!-- copyright footer -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="footer-bottom-content">
                        &copy; {{ \Carbon\Carbon::now()->year }} All rights reserved Anjumane Asharafia Bangladesh
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="footer-bottom-content">
                        <ul class="footer-bottom-nav">
                            <li><a href="">Privacy & Policy</a></li>
                            <li><a href="">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
